/* By Zachary Robert James */ 
/* START */ 

#include <stdio.h>

#define TOTAL_ELEMENTS ((sizeof(array) / sizeof(array[0]))) // array[0] ...
int array[] = {1, 3, 15, 19, 0, 43, 12};

int main(int argc, char *argv[])
{ /* main */
	//printf("Code starts at main?? T_E: %ld, arr[0]: %d\n", TOTAL_ELEMENTS, array[0]);
	int i;

	// key takeaway: total_elements is an unsigned long, so to compare it with int i, it must be casted to an integer
	for(i = -1; i <= (int) TOTAL_ELEMENTS - 2; i++)
	{ /* f */
		printf("Element %d has value %d\n", i + 1, array[i + 1]);
	} /* f */
	
	//printf("Right before the return - loop should have run");
	return 0;

} /* main */

/* END */ 
