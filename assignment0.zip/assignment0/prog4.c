/* By: Zachary Robert James */ 
/* START */ 

#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{ /* main */ 
	unsigned long *p = malloc(sizeof(unsigned long)); // allocating memory for one unsigned long
	*p = 0xdeadbeefcafeba00; // assinging the hexadecimal value to the memory pointed to by p
	int i;

	//unsinged char *byte_ptr = (unsigned char *)p;

	// output the individual bytes of the unsigned long value... or not?
	for(i = 0; i < sizeof(unsigned long); i++)
	{ /* f */ 
		printf("%02x ", *((unsigned char *)p + i));
		//p++; /* increments p, a pointer to an unsigned long, moving the pointer by the size of the unsigned long, causing the pointer to move out of the allocated memory block and access invalid memory */
		// p is cast to 'unsigned char *', pointing to the individual bytes instead of a full unsigned long;
		// '(unsigned char *)p + i' calculates memory address of i-th byte
		// '*(...)' dereferences address to get the value
	} /* f */ 

	printf("\n"); // printing the results in little endian style is finished, so new line

	free(p); // delocating and freeing the allocated memory

	return 0;

} /* main */

/* END */ 
