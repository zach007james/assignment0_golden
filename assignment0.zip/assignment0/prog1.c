/* By: Zachary Robert James */ 
/* START */ 

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#define BUFSIZE 1024 // size limit to test if longer than 1024 characters

int cmp(const void *a, const void *b)
{ /* cmp */ 
	const char *str1 = *(const char **)a;
	const char *str2 = *(const char **)b;
	return strcmp(str1, str2);
} /* cmp */ 

int main(int argc, char *argv[])
{ /* main */

	/* grabbing initial n input and setting it up */ 
	// Initializing needed variables:
	int n = 0; // will hold the interger of the buf asci atoi conversion - ultimately representing the number of lines

	char buf[BUFSIZE + 1]; // size limit (as one is used for the exit char) / (used to hold read input and limit it)

	printf("Enter the number of strings you will input today: "); // prompts the user
	fflush(stdout); // forces the buffer to be written to the output immediately (when it usually waits for the buffer to be full to do this) - so we can see the printf text
	// fgets: char *fgets(char *str, int n, FILE *stream);
	fgets(buf, BUFSIZE + 1, stdin);

	n = atoi(buf); // 'ASCII-to-integer'

	char *lines[n]; // create the array to hold the pointers
	
	/* grabbing initial n input and setting it up */ 

	/* dealing with the rest of the input */ 
	for(int i = 0; i < n; i++)
	{ /* f */ 
		//memset(buf, 0, sizeof(buf)); // clear buffer (may be redundant)
		fgets(buf, BUFSIZE + 1, stdin); // reads input line into buf with max size of bufsize + 1 from stdin
		size_t len_of_buf = strlen(buf);
		buf[len_of_buf - 1] == '\n' ? buf[len_of_buf - 1] = '\n' : 0;
	
		lines[i] = malloc(len_of_buf + 1);
		strcpy(lines[i], buf);
	} /* f */ 
	/* dealing with the rest of the input */ 

	/* sorting */ 
	qsort(lines, n, sizeof(char *), cmp);	
	/* sorting */

	/* output sorted result */ 
	for(int i = 0; i < n; i++)
	{ /* f */ 
		printf("%s\n", lines[i]); // output the line
		free(lines[i]); // free memory of line after outputted
	} /* f */ 
	/* output sorted result */ 

	return 0; // signals that the program has run successfully (standard practice)
} /* main */

/* END */ 
