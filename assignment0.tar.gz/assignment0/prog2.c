/* By: Zachary Robert James */ 

/* START */ 

#include <stdio.h>

// forward declarations - allowing me to call them before their implementations are encountered
int my_openit(char *name, int prot);
void my_closeit();

int my_openit(char *name, int prot)
{ /* my_openit */ 
	printf("My open it has run with name %s and prototype %d!\n", name, prot);	
	return 0;
} /* my_openit */ 

void my_closeit()
{ /* my_closeit */ 
	printf("My close it has run!\n");
} /* my_closeit */

// struct with two function pointers with functions of signatures openit and closeit
typedef struct funcs
{ /* funcs */ 
	int (*openit)(char *name, int prot);
	void (*closeit)(void);
} funcs; /* funcs */ 

// f takes a pointer to a funcs and assignes my_openit and my_closeit to the given func_ptr locations
void f(funcs *func_ptr)
{ /* f() */ 
	func_ptr->openit = my_openit;
	func_ptr->closeit = my_closeit;
} /* f() */ 

int main(int argc, char *argv[])
{ /* main */ 
	/* Part 1 */ 
	//my_openit("testname", 007);
	//my_closeit();
	/* Part 1 */

	/* Part 2 */ 
	//funcs my_funcs_pointers = { .openit = my_openit, .closeit = my_closeit };
	/* Part 2 */ 

	/* Part 3 */ 
	funcs my_func_var_ptr; // variable of type funcs
	f(&my_func_var_ptr); // initializing the function pointer with f method

	my_func_var_ptr.openit("testname", 007); // calling openit through the funcs variable
	my_func_var_ptr.closeit();
	/* Part 3 */

	return 0;
} /* main */ 

/* END */ 
