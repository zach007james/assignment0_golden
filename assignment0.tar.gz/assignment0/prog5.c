/* By: Zachary Robert James */ 
/* START */ 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{ /* main */
	/* error check for an argument */
	if(argc != 2)
	{ /* i */ 	
		printf("Usage: %s <your_arg>\n", argv[0]);
		return 0;
	} /* i */ 
	/* error check for an argument */

	/* take in the argument */
	char *file_name = malloc((strlen(argv[1]) + 1) * sizeof(char)); // allocating memory for the file name (with + 1 for the null terminator)
	strcpy(file_name, argv[1]); // copying the argument to the allocated space
	/* take in the argument */
	
	/* open the file */
	FILE *my_file_ptr;
	my_file_ptr = fopen(file_name, "r");

	/* open the file */

	/* error check for opening file */
	if(my_file_ptr == NULL)
	{ /* i */ 
		printf("Could not open this file - rerun the program and retry the file name\n");
		return 1;
	} /* i */
	/* error check for opening file */

	/* allocate space and read file */ 
	char *buf; // char arr (string) to hold the entire file contents
	long file_size;

	fseek(my_file_ptr, 0, SEEK_END); // moves to end of file
	file_size = ftell(my_file_ptr); // byte offset (file size)
	rewind(my_file_ptr); // going back to beginning of file
	
	buf = (char *)malloc((file_size + 1) * sizeof(char));

	fread(buf, sizeof(char), file_size, my_file_ptr);
	/* allocate space and read file */

	/* close file and terminate string */
	buf[file_size] = '\0'; // terminating the string
	fclose(my_file_ptr);
	/* close file and terminate string */ 

	/* tokenize string and output it */
	const char delimiter_args[] = " ,\n\t";

	char *my_token = strtok(buf, delimiter_args); // first token (so null while condition works)
	
	while(my_token != NULL)
	{ /* w */ 
		printf("%s\n", my_token);
		my_token = strtok(NULL, delimiter_args); // 'NULL' in the first argument allows you to keep tokenizing the same string
	} /* w */ 
	/* tokenize string and output it */
	
	free(file_name); // freeing the file name variable 
	
	return 0;

} /* main */ 

/* END */ 
