int main(){for(int i=0;i<5;i++){printf("%sX X X X X\n",i%2?"":" ");}}
